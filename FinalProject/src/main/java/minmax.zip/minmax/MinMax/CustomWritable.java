/*package minmax.MinMax;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableUtils;

public class CustomWritable implements Writable{
  
    private String date;
    private int stock_vol;
    private String stock_price;
    
    public CustomWritable()
    {
        
    }

    public CustomWritable(String d, int sv, String sp)
    {
        this.date = d;
        this.stock_vol = sv;
        this.stock_price = sp;
    }
    
     @Override
    public void write(DataOutput d) throws IOException {
        WritableUtils.writeString(d, date);
        WritableUtils.writeVInt(d, stock_vol);
        WritableUtils.writeString(d, stock_price);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        date = WritableUtils.readString(di);
        stock_vol = WritableUtils.readVInt(di);
        stock_price = WritableUtils.readString(di);
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getStock_vol() {
        return stock_vol;
    }

    public void setStock_vol(int stock_vol) {
        this.stock_vol = stock_vol;
    }

    public String getStock_price() {
        return stock_price;
    }

    public void setStock_price(String stock_price) {
        this.stock_price = stock_price;
    }
    
      
        public String toString()
    {
        return ("");
    }
}
*/