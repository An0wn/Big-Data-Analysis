package minmax.MinMax;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
public class MinMax_Reducer extends Reducer<CompositeKeyWritable, Text,CompositeKeyWritable, Text>{
    
   
    public void reduce(CompositeKeyWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException
    {
    try{
    int max = Integer.MIN_VALUE;
    int min = Integer.MAX_VALUE;
    int f_count = 0;
    int m_count = 0;
    int v_count =0;
 //   String max_of_type="";
 //   String min_of_type="";

        for (Text val : values)
            {
        	if(val.equals("FELONY"))
        	{
        		f_count += 1;
        	}
        	if(val.equals("MISDEMEANOR"))
        	{
        		m_count += 1;
        	}
        	if(val.equals("VIOLATION"))
        	{
        		v_count += 1;
        	}
            }
        int total_count = f_count+m_count+v_count;
        float percent_f = (f_count/total_count)*100;
        float percent_m = (m_count/total_count)*100;
        float percent_v = (v_count/total_count)*100;
        String avg= String.valueOf(percent_f)+" "+String.valueOf(percent_m)+" "+String.valueOf(percent_v);

        //context.write(key,new Text(max_of_type + " " + max + " " + min_of_type + " " + min));
      //  new StringBuilder().append(String.valueOf(avg_f)).toString();
        context.write(key,new Text(avg));
        /*        
        if(f_count > m_count && f_count > v_count)
        {
        	max = f_count;
        	max_of_type = "FELONY";
        }
        else if(m_count > f_count && m_count > v_count)
        {
        	max = m_count;
        	max_of_type = "MISDEMEANOR";
        }
        else
        {
        	max = v_count;
        	max_of_type = "VIOLATION";
        }
        
        if(f_count < m_count && f_count < v_count)
        {
        	min = f_count;
        	min_of_type = "FELONY";
        }
        else if(m_count < f_count && m_count < v_count)
        {
        	min = m_count;
        	min_of_type = "MISDEMEANOR";
        }
        else
        {
        	min = v_count;
        	min_of_type = "VIOLATION";
        }*/
        

    }
    catch(Exception e)
    {
    	e.printStackTrace();
    }
    }
}
